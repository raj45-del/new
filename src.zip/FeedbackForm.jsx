import { useEffect, useState } from "react"

function FeedbackForm(){
    
const [name,setName]=useState("")
const [department,setDepartment]=useState("")
const [feedback, setFeedback] = useState("");
const [rating, setRating] = useState("");
const [submittedData, setSubmittedData] = useState([]);

function handleSubmit(e){
    e.preventDefault();

    if(!name || !department || !feedback || !rating){
        alert("Fill all fienlds");
        return;
    }

    const newEntry={name, department, feedback, rating};
    setSubmittedData([...submittedData, newEntry]);

    setName("");
    setDepartment("")
    setFeedback("")
    setRating(" ")

}

    return (
        <div>
            <form onSubmit={handleSubmit}> 
            <div>Name: <input type="text" 
            onChange={(e)=>{setName(e.target.value)}}
            /></div>
            <br />
            <div>Department: <select onChange={(e)=>{setDepartment(e.target.value)}}>
            <option>Select an  Option</option>
            <option value="one">One</option> 
            <option value="two">Twe</option>
            <option value="three">Three</option>
            </select>
            </div>
            <br/>
            <div>Feedback: <textarea onChange={(e)=>setFeedback(e.target.value)}></textarea> </div>
            <br />
            <div>Rating: 
                <input type="radio" value="1" checked={rating==='1'} onChange={(e)=>setRating(e.target.value)}/>1
                <input type="radio" value="2" checked={rating==='2'} onChange={(e)=>setRating(e.target.value)}/>2
                <input type="radio" value="3" checked={rating==='3'} onChange={(e)=>setRating(e.target.value)}/>3
                <input type="radio" value="4" checked={rating==='4'} onChange={(e)=>setRating(e.target.value)}/>4
                <input type="radio" value="5" checked={rating==='5'} onChange={(e)=>setRating(e.target.value)}/>5
            </div>

            <div><button type="submit">Submit</button></div>
            </form>

           <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Feedback</th>
                    <th>Rating</th>
                </tr>
            </thead>
            <tbody>
                {submittedData.map((d,i)=>(
                    <tr key={i}>
                    <td>{d.name}</td>
                    <td>{d.department}</td>
                    <td>{d.feedback}</td>
                    <td>{d.rating}</td>
                  </tr>
                ))}
            </tbody>
           </table>
          
        </div>
    )
}

export default FeedbackForm