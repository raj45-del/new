import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import New from './new'
import ProductList from './ProductList'
import FeedbackForm from './FeedbackForm'
import PrList from './list'

function App() {
  const [name, setName] = useState()
  const [password, setPassword] = useState()
  const [music, setMusic] = useState()
  const [gaanja, setGaanja] = useState()
  const [coding, setCoding] = useState()
  const [football, setFootball] = useState()
  const [gender, setGender] = useState()

useEffect(()=>{
  localStorage.setItem('name', name)
}, [name])
useEffect(()=>{
  localStorage.setItem('password', password)
}, [password])
useEffect(()=>{
  localStorage.setItem('music', music)
}, [music])
useEffect(()=>{
  localStorage.setItem('gaanja', gaanja)
}, [gaanja])
useEffect(()=>{
  localStorage.setItem('coding', coding)
}, [coding])
useEffect(()=>{
  localStorage.setItem('football', football)
}, [football])
useEffect(()=>{
  localStorage.setItem('gender', gender)
}, [gender])


useEffect(()=>{
  setName(localStorage.getItem('name'))
  setPassword(localStorage.getItem('password'))
  setMusic(localStorage.getItem('music'))
  setGaanja(localStorage.getItem('gaanja'))
  setCoding(localStorage.getItem('coding'))
  setFootball(localStorage.getItem('football'))
  setM(localStorage.getItem('gender'))
},[])

  return (
    <>
      <div>
        
        {/* <ProductList/> */}
        {/* <FeedbackForm/> */}

        {/* <PrList/> */}
        
        <label>Name: </label>
        <input type='text' onChange={e=>setName(e.target.value)} value={name} />
        <br></br>
        <br></br>
        <label>Password: </label>
        <input type='text' onChange={e=>setPassword(e.target.value)} value={password} />
        <br></br>
        <br></br>

        <label>Hobbies: </label>
        Music <input type='checkbox' onChange={e=>setMusic(e.target.value)} checked={music}></input>
        Gaanjaa <input type='checkbox' onChange={e=>setGaanja(e.target.value)} checked={gaanja}></input>
        Coding <input type='checkbox' onChange={e=>setCoding(e.target.value)} checked={coding}></input>
        Football <input type='checkbox' onChange={e=>setFootball(e.target.value)} checked={football}></input>
        <br></br>
        <br></br>
        <label>Gender: </label>
        M <input type='radio' name='gender' value='M' checked={gender==='M'} onChange={e=>setGender(e.target.value)} />
        F <input type='radio' name='gender' value='F' checked={gender==='F'}  onChange={e=>setGender(e.target.value)} />      
        
        <h2>Ohh Vedcho Run hogya</h2>
         //create a FeedbackForm 
         




      </div>
    
    </>
  )
}

export default App
