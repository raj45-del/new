function New(){
    return(
        <div>
            <div>C</div>
            <h1>Fir Sex hogya bedcho</h1>
            
        </div>
    )
}

export default New;
