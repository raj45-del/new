import { useEffect,useState } from "react"


function PrList(){

    const [fetchedData, setFetchedData]= useState(null)

    function fetchData(){
        fetch("https://fakestoreapi.com/products")
        .then((res)=>{
            return res.json()
        })
        .then((data=>{
            setFetchedData(data)
        }))
    }
    console.log(fetchedData)


    useEffect(()=>{
        fetchData()
    },[])

    return(
        <div>
            <div>
                {
                    fetchedData &&
                    fetchedData.map((item)=>{
                        return <div key={item.id}>
                        <img src={item.image} alt=""/>
                        </div>
                    })
                }
            </div>
        </div>
    )
}

export default PrList


